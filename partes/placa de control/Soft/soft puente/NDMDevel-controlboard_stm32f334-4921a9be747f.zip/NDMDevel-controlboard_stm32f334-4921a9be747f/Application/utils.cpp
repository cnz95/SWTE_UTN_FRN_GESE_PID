/*
 * utils.cpp
 *
 *  Created on: Jun 1, 2023
 *      Author: Damian
 */
#include "utils.h"

/*
 * Credits to: https://stackoverflow.com/a/67521458/2538072
 */
float atofn(const char *arr,uint32_t n)
{
    float val = 0;
    int afterdot=0;
    float scale=1;
    int neg = 0;

    if (*arr == '-') {
        arr++;
        neg = 1;
    }
    while (*arr) {
        if (afterdot) {
            scale = scale/10;
            val = val + (*arr-'0')*scale;
        } else {
            if (*arr == '.')
                afterdot++;
            else
                val = val * 10.0 + (*arr - '0');
        }
        arr++;
    }
    if(neg) return -val;
    else    return  val;
}
/*
 * Credits to: https://www.geeksforgeeks.org/cpp-program-to-write-your-own-atoi/
 */
int atoin(const char* str,uint32_t n)
{
    int res = 0;
    for (uint32_t i = 0; str[i] != '\0' && i<n; ++i)
        res = res * 10 + str[i] - '0';
    return res;
}
bool is_numn(const char* arr,uint32_t n)
{
    for( uint32_t i=0 ; i<n ; i++ )
        if( (arr[i]<'0' || arr[i]>'9') )
            return false;
    return true;
}
bool is_alfanumn(const char* arr,uint32_t n)
{
    for( uint32_t i=0 ; i<n ; i++ )
        if( (arr[i]<'0' || arr[i]>'9') && (arr[i]!='.' && arr[i]!='-') )
            return false;
    return true;
}
