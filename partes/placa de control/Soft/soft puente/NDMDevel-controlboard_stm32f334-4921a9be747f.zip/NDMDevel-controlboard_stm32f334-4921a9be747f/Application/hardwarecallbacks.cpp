/*
 * hardwarecallbacks.cpp
 *
 *  Created on: May 31, 2023
 *      Author: Damian
 */

#include "hardwarecallbacks.h"
#include "uart_driver.h"
#include "io_driver.h"

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if( huart == &huart2 )
	{
		wte::uart_rx_reception();
	}
}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if( huart == &huart2 )
	{
		wte::uart_tx_completed();
	}
}
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	if( hadc == &hadc1 )
	{
		wte::adc_sample_acquired();
	}
}
