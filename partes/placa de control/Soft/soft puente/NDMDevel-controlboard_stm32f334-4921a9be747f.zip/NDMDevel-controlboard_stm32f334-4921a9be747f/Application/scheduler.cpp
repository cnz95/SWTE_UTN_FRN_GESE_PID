/*
 * scheduler.cpp
 *
 *  Created on: May 25, 2023
 *      Author: Damian
 */

#include "scheduler.h"
#include "usart.h"
#include "dac.h"
#include "TimerImp.h"
#include "main.h"
#include "io_driver.h"
#include "uart_driver.h"
#include "uart_com_imp.h"
int global;
void scheduler()
{
	//setup
	wte::analog_init();

	//define supported commands on uart, and install processors for them
	constexpr wte::command_metadata_t commands[] =
	{
		{"read"	,wte::read },
		{"write",wte::write},
		{"reset",wte::reset},
		{"conf" ,wte::conf },
		{"help" ,wte::help }
	};
	wte::uart_rx_init( commands , sizeof(commands)/sizeof(wte::command_metadata_t) );

	while( true )
	{
		wte::uart_rx_task();
		wte::autoread_task();
	}
}
