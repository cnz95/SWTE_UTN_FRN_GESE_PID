/*
 * dio.h
 *
 *  Created on: May 29, 2023
 *      Author: Damian
 */

#pragma once

#include <cstdint>

namespace wte
{

enum class digital_in : uint8_t
{
	in0,
	in1,
	in2,
	in3,
	io_in0,
	io_in1,
	io_in2,
	io_in3,
};

enum class digital_out : uint8_t
{
	out0,
	out1,
	out2,
	out3,
	out4,
	io_out0,
	io_out1,
	io_out2,
	io_out3,
};

enum class analog_in : uint8_t
{
	in0,
	in1
};

enum class analog_out : uint8_t
{
	out0,
	out1
};

/**
 * @brief initializes the analog hardware (ADC and DAC)
 *
 * This function must be invoked before read_analog_in() or
 * write_analog_out().
 *
 */
void analog_init();

/**
 * @brief Reads a digital input channel
 */
bool  read_digital_in  (digital_in  channel);

/**
 * @brief Writes a digital output channel
 */
void  write_digital_out(digital_out channel,bool state);

/**
 * @brief Read a digital output channel
 */
bool  read_digital_out(digital_out channel);

/**
 * @brief reads the adc analog channel
 *
 * @param channel identify the adc channel to read
 * @param convertion_factor is function used to convert the 12bits adc sample to float
 * 		  The default implementation maps [0:4095] to [0:100].
 * @returns value between 0 to 100 in float format
 */
float read_analog_in   (analog_in channel,float(*convertion_factor)(uint16_t)=[](uint16_t sample)->float{ return float(sample)*100.0f/4095.0f; });

/**
 * @brief writes the dac analog channel
 *
 * @param channel identify the dac channel to write
 * @param value to write in the range [0:100]
 * @param convertion_factor is a function used to convert the float input value
 * 		  to a 12bit dac value. The default implementation assumes that the input
 * 		  is in the range [0:100] and will write the dac output channel with
 * 		  a value in the range [0:4095].
 */
void  write_analog_out (analog_out channel,float value,uint16_t(*convertion_factor)(float) = [](float value)->uint16_t{ return uint16_t(value/100.0f*4095.0f); });

/**
 * @brief reads the dac analog channel
 *
 * @param channel identify the dac channel to write
 * @param convertion_factor is a function used to convert the float input value
 * 		  to a 12bit dac value. The default implementation assumes that the input
 * 		  is in the range [0:100] and will write the dac output channel with
 * 		  a value in the range [0:4095].
 * @returns value between 0 to 100 in float format
 */
float read_analog_out (analog_out channel,float(*convertion_factor)(uint16_t)=[](uint16_t sample)->float{ return float(sample)*100.0f/4095.0f; });

/**
 * @brief must be called whenever the hardware gets a new adc sample
 */
void adc_sample_acquired();

}	//namespace wte
