/*
 * uartcomimp.h
 *
 *  Created on: Jun 1, 2023
 *      Author: Damian
 */

#pragma once

#include <cstdint>

namespace wte
{

bool read	 (const char* arg,uint32_t len);
bool write	 (const char* arg,uint32_t len);
bool reset	 (const char* arg,uint32_t len);
bool conf	 (const char* arg,uint32_t len);
bool help	 (const char* arg,uint32_t len);

void autoread_task();

}//namespace wte

