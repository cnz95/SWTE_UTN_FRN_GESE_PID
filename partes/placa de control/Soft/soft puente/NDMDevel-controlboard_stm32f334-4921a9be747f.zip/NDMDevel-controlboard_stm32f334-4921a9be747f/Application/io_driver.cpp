/*
 * dio.cpp
 *
 *  Created on: May 29, 2023
 *      Author: Damian
 */

#include "io_driver.h"
#include "main.h"
#include "dac.h"
#include "adc.h"
#include "tim.h"
#include "double_buffer.h"


namespace wte
{
//forward declaration
static void irq_on_off(bool enable);

//types declaration
struct AdcBundle
{
	uint16_t sample[2];
};

//variable declaration
static double_buffer_t<AdcBundle,irq_on_off> adc_double_buffer;

//private functions
static void irq_on_off(bool enable)
{
	if( enable )
		HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
	else
		HAL_NVIC_DisableIRQ(DMA1_Channel1_IRQn);
}

//public functions
void analog_init()
{
	HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
	HAL_DAC_Start(&hdac1,DAC_CHANNEL_1);
	HAL_DAC_Start(&hdac1,DAC_CHANNEL_2);
	//tim15 produce an UpdateEvent every 100us
	//the adc will start a new acquisition when the UpdateEvent is produced
	//(every acquisition of the adc includes both analog channels)
	HAL_TIM_Base_Start(&htim15);

	//The adc is configured to send two samples of half words (16 bits) to the destination buffer.
	//And the destination buffer must be uint32_t (required by the HAL driver), so a
	//reinterpret_cast is needed.
	//The HAL driver will use the busy buffer to store the adc samples through the DMA.
	uint32_t* dest = reinterpret_cast<uint32_t*>( adc_double_buffer.busy_buffer() );
	HAL_ADC_Start_DMA(&hadc1,dest,2);
}
void write_digital_out(digital_out channel,bool state)
{
	switch( channel )
	{
		case digital_out::out0:
			HAL_GPIO_WritePin(MCU_OUT_0_GPIO_Port,MCU_OUT_0_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::out1:
			HAL_GPIO_WritePin(MCU_OUT_1_GPIO_Port,MCU_OUT_1_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::out2:
			HAL_GPIO_WritePin(MCU_OUT_2_GPIO_Port,MCU_OUT_2_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::out3:
			HAL_GPIO_WritePin(MCU_OUT_3_GPIO_Port,MCU_OUT_3_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::out4:
			HAL_GPIO_WritePin(MCU_OUT_4_GPIO_Port,MCU_OUT_4_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::io_out0:
			HAL_GPIO_WritePin(MCU_IO_OUT_0_GPIO_Port,MCU_IO_OUT_0_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::io_out1:
			HAL_GPIO_WritePin(MCU_IO_OUT_1_GPIO_Port,MCU_IO_OUT_1_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::io_out2:
			HAL_GPIO_WritePin(MCU_IO_OUT_2_GPIO_Port,MCU_IO_OUT_2_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
		case digital_out::io_out3:
			HAL_GPIO_WritePin(MCU_IO_OUT_3_GPIO_Port,MCU_IO_OUT_3_Pin,state?GPIO_PIN_SET:GPIO_PIN_RESET);
			break;
	}
}
bool read_digital_in(digital_in  channel)
{
	switch( channel )
	{
		case digital_in::in0:
			return HAL_GPIO_ReadPin(MCU_IN_0_GPIO_Port, MCU_IN_0_Pin) == GPIO_PIN_SET;
		case digital_in::in1:
			return HAL_GPIO_ReadPin(MCU_IN_1_GPIO_Port, MCU_IN_1_Pin) == GPIO_PIN_SET;
		case digital_in::in2:
			return HAL_GPIO_ReadPin(MCU_IN_2_GPIO_Port, MCU_IN_2_Pin) == GPIO_PIN_SET;
		case digital_in::in3:
			return HAL_GPIO_ReadPin(MCU_IN_3_GPIO_Port, MCU_IN_3_Pin) == GPIO_PIN_SET;
		case digital_in::io_in0:
			return HAL_GPIO_ReadPin(MCU_IO_IN_0_GPIO_Port, MCU_IO_IN_0_Pin) == GPIO_PIN_SET;
		case digital_in::io_in1:
			return HAL_GPIO_ReadPin(MCU_IO_IN_1_GPIO_Port, MCU_IO_IN_1_Pin) == GPIO_PIN_SET;
		case digital_in::io_in2:
			return HAL_GPIO_ReadPin(MCU_IO_IN_2_GPIO_Port, MCU_IO_IN_2_Pin) == GPIO_PIN_SET;
		case digital_in::io_in3:
			return HAL_GPIO_ReadPin(MCU_IO_IN_3_GPIO_Port, MCU_IO_IN_3_Pin) == GPIO_PIN_SET;
	}
	return false;
}
bool  read_digital_out(digital_out channel)
{
	switch( channel )
	{
		case digital_out::out0:
			return HAL_GPIO_ReadPin(MCU_OUT_0_GPIO_Port,MCU_OUT_0_Pin)==GPIO_PIN_SET;
		case digital_out::out1:
			return HAL_GPIO_ReadPin(MCU_OUT_1_GPIO_Port,MCU_OUT_1_Pin)==GPIO_PIN_SET;
		case digital_out::out2:
			return HAL_GPIO_ReadPin(MCU_OUT_2_GPIO_Port,MCU_OUT_2_Pin)==GPIO_PIN_SET;
		case digital_out::out3:
			return HAL_GPIO_ReadPin(MCU_OUT_3_GPIO_Port,MCU_OUT_3_Pin)==GPIO_PIN_SET;
		case digital_out::out4:
			return HAL_GPIO_ReadPin(MCU_OUT_4_GPIO_Port,MCU_OUT_4_Pin)==GPIO_PIN_SET;
		case digital_out::io_out0:
			return HAL_GPIO_ReadPin(MCU_IO_OUT_0_GPIO_Port,MCU_IO_OUT_0_Pin)==GPIO_PIN_SET;
		case digital_out::io_out1:
			return HAL_GPIO_ReadPin(MCU_IO_OUT_1_GPIO_Port,MCU_IO_OUT_1_Pin)==GPIO_PIN_SET;
		case digital_out::io_out2:
			return HAL_GPIO_ReadPin(MCU_IO_OUT_2_GPIO_Port,MCU_IO_OUT_2_Pin)==GPIO_PIN_SET;
		case digital_out::io_out3:
			return HAL_GPIO_ReadPin(MCU_IO_OUT_3_GPIO_Port,MCU_IO_OUT_3_Pin)==GPIO_PIN_SET;
	}
	return false;
}
float read_analog_in(analog_in channel,float(*convertion_factor)(uint16_t))
{
	auto adc = adc_double_buffer.atomic_read();
	switch( channel )
	{
	case analog_in::in0:
		return convertion_factor(adc.sample[1]);
	case analog_in::in1:
		return convertion_factor(adc.sample[0]);
	}
	return 0.0f;
}
void write_analog_out(analog_out channel,float value,uint16_t(*convertion_factor)(float))
{
	switch( channel )
	{
	case analog_out::out0:
		HAL_DAC_SetValue(&hdac1,DAC_CHANNEL_2,DAC_ALIGN_12B_R,convertion_factor(value));
		break;
	case analog_out::out1:
		HAL_DAC_SetValue(&hdac1,DAC_CHANNEL_1,DAC_ALIGN_12B_R,convertion_factor(value));
		break;
	}
}
float read_analog_out (analog_out channel,float(*convertion_factor)(uint16_t))
{
	switch( channel )
	{
	case analog_out::out0:
		return convertion_factor(HAL_DAC_GetValue(&hdac1,DAC_CHANNEL_2));
	case analog_out::out1:
		return convertion_factor(HAL_DAC_GetValue(&hdac1,DAC_CHANNEL_1));
	}
	return 0.0f;
}

void adc_sample_acquired()
{
	wte::adc_double_buffer.switch_buffer();
	HAL_ADC_Start_DMA(&hadc1,reinterpret_cast<uint32_t*>( wte::adc_double_buffer.busy_buffer() ),2);
}

}//namespace wte



