/*
 * isrcpp.h
 *
 *  Created on: May 31, 2023
 *      Author: Damian
 */

#pragma once

#ifdef __cplusplus
extern "C"{
#endif

//isr handlers


#ifdef __cplusplus
}
#endif
