/*
 * SysTimer.h
 *
 *  Created on: Oct 4, 2021
 *      Author: Damian
 */

#ifndef SYSTIMER_HPP_
#define SYSTIMER_HPP_

#include "Timer.h"
#include "main.h"

//System Timer (32bits 1ms)
using SysTick_ms = mcu::Timer<uint32_t,1,1000,HAL_GetTick>;

using Tim32_us = mcu::Timer<uint32_t,1,1000000,[]{ return *reinterpret_cast<uint32_t*>(TIM2_BASE + 0x24); }>;


#endif /* SYSTIMER_HPP_ */
