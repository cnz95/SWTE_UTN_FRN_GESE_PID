/*
 * uart_driver.h
 *
 *  Created on: May 30, 2023
 *      Author: Damian
 */

#pragma once
#include <cstdint>

namespace wte
{
//Rx
struct command_metadata_t
{
	char name[12];
	bool (*processor)(const char*,uint32_t);
};
//public
void uart_rx_init(const command_metadata_t* info,uint32_t len);
void uart_rx_task();
//hardware invoked
void uart_rx_reception();

//Tx
//public
bool uart_tx_busy();
void uart_tx_send(const char* data,uint32_t len);
//hardware invoked
void uart_tx_completed();

}//namespace wte
