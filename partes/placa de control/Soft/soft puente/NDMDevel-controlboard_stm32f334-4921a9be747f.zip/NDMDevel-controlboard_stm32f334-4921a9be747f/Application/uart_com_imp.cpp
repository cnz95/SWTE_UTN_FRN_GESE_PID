/*
 * uartcomimp.cpp
 *
 *  Created on: Jun 1, 2023
 *      Author: Damian
 */

#include "uart_com_imp.h"
#include "utils.h"
#include "io_driver.h"
#include <cstring>
#include <cstdio>
#include <cstdint>
#include "uart_driver.h"
#include "TimerImp.h"

namespace wte
{
static enum class parser_conf_t : uint8_t
{
	quiet,
	verbose,
	autoread

}_parser_conf = parser_conf_t::verbose;

static SysTick_ms _autoread_tim(true);
static uint32_t   _autoread_dt = 100;	//100ms
static void read_all_io(char* str,uint32_t* str_len);

bool read(const char* arg,uint32_t len)
{
	//if autoread enabled, not answer can be send until
	//autoread is switched off
	if( _parser_conf == parser_conf_t::autoread )
		return false;

	//if tx busy, cant send rensponse, so wait until tx
	//become not busy...
	if( uart_tx_busy() )
		return true;

	if( strncmp(arg,"an",len-1) == 0 && len == 3 )
	{
		char str[32];
		if( arg[len-1] == '0' )
		{
			switch( _parser_conf )
			{
			case parser_conf_t::quiet:
				sprintf(str,"%.2f",read_analog_in(analog_in::in0));
				break;
			case parser_conf_t::verbose:
				sprintf(str," > read an0 %.2f",read_analog_in(analog_in::in0));
				break;
			case parser_conf_t::autoread:
				return false;
			}
		}
		else if( arg[len-1] == '1' )
		{
			switch( _parser_conf )
			{
			case parser_conf_t::quiet:
				sprintf(str,"%.2f",read_analog_in(analog_in::in1));
				break;
			case parser_conf_t::verbose:
				sprintf(str," > read an1 %.2f",read_analog_in(analog_in::in1));
				break;
			case parser_conf_t::autoread:
				return false;
			}
		}
		else
			return false;
		uart_tx_send(str,strlen(str));
		return false;
	}
	if( strncmp(arg,"dio",len-1) == 0 && len == 4 )
	{
		if( arg[len-1] < '0' || arg[len-1] > '3' )
			return false;
		auto dio = static_cast<digital_in>((uint8_t(arg[len-1])-uint8_t('0'))+static_cast<uint8_t>(digital_in::io_in0));
		char str[32];
		switch( _parser_conf )
		{
		case parser_conf_t::quiet:
			sprintf(str,"%d",read_digital_in(dio));
			break;
		case parser_conf_t::verbose:
			sprintf(str," > read dio%c %d",arg[len-1],read_digital_in(dio));
			break;
		case parser_conf_t::autoread:
			return false;
		}
		uart_tx_send(str,strlen(str));
		return false;
	}
	if( strncmp(arg,"di",len-1) == 0 && len == 3 )
	{
		if( arg[len-1] < '0' || arg[len-1] > '3' )
			return false;
		auto di = static_cast<digital_in>((uint8_t(arg[len-1])-uint8_t('0'))+static_cast<uint8_t>(digital_in::in0));
		char str[32];
		switch( _parser_conf )
		{
		case parser_conf_t::quiet:
			sprintf(str,"%d",read_digital_in(di));
			break;
		case parser_conf_t::verbose:
			sprintf(str," > read di%c %d",arg[len-1],read_digital_in(di));
			break;
		case parser_conf_t::autoread:
			return false;
		}
		uart_tx_send(str,strlen(str));
		return false;
	}
	if( strncmp(arg,"all",len-1) == 0 && len == 3 )
	{
		char data[48];
		char str[64];
		uint32_t len = sizeof(data);
		read_all_io(data,&len);
		switch( _parser_conf )
		{
		case parser_conf_t::quiet:
			sprintf(str,"%s",data);
			break;
		case parser_conf_t::verbose:
			sprintf(str," > read all %s",data);
			break;
		case parser_conf_t::autoread:
			return false;
		}
		uart_tx_send(str,strlen(str));
		return false;
	}
    return false;
}
bool write(const char* arg,uint32_t len)
{
	if( arg == nullptr || len == 0 )
		return false;
	if( uart_tx_busy() && (_parser_conf == parser_conf_t::verbose) )
		return true;
	if( auto split = strnsplit(arg,len,' ') )
	{
		auto[ch,ch_len,val,val_len] = split.value();
		if( !is_alfanumn(val,val_len) )
			return false;
		float f_value = atofn(val,val_len);
		if( strncmp(ch,"an",ch_len-1) == 0 && ch_len == 3 &&
			(ch[ch_len-1] == '0' || ch[ch_len-1] == '1'))
		{
			if( ch[ch_len-1] == '0' )
				write_analog_out(analog_out::out0,f_value);
			if( ch[ch_len-1] == '1' )
				write_analog_out(analog_out::out1,f_value);
			if( _parser_conf == parser_conf_t::verbose )
			{
				char str[32];
				sprintf(str," > write an%c %.2f",ch[ch_len-1],f_value);
				uart_tx_send(str,strlen(str));
			}
			return false;
		}
		if( strncmp(ch,"dio",ch_len-1) == 0 && ch_len == 4 &&
			(ch[ch_len-1] >= '0' && ch[ch_len-1] <= '3') )
		{
			auto dio = static_cast<digital_out>((uint8_t(ch[ch_len-1])-uint8_t('0'))+static_cast<uint8_t>(digital_out::io_out0));
			bool value = (f_value != 0.0f);
			write_digital_out(dio,value);
			if( _parser_conf == parser_conf_t::verbose )
			{
				char str[32];
				sprintf(str," > write dio%c %d",arg[ch_len-1],value);
				uart_tx_send(str,strlen(str));
			}
			return false;
		}
		if( strncmp(ch,"do",ch_len-1) == 0 && ch_len == 3 &&
			(ch[ch_len-1] >= '0' && ch[ch_len-1] <= '4') )
		{
			auto _do = static_cast<digital_out>((uint8_t(ch[ch_len-1])-uint8_t('0'))+static_cast<uint8_t>(digital_out::out0));
			bool value = (f_value != 0.0f);
			write_digital_out(_do,value);
			if( _parser_conf == parser_conf_t::verbose )
			{
				char str[32];
				sprintf(str," > write do%c %d",arg[ch_len-1],value);
				uart_tx_send(str,strlen(str));
			}
			return false;
		}
	}
    return false;
}
bool reset(const char* arg,uint32_t len)
{
	if( uart_tx_busy() && (_parser_conf == parser_conf_t::verbose) )
		return true;
	for( uint8_t ch=static_cast<uint8_t>(digital_out::out0) ;
		 ch <= static_cast<uint8_t>(digital_out::io_out3) ;
		 ch++ )
		write_digital_out(static_cast<digital_out>(ch),false);
	write_analog_out(analog_out::out0,0);
	write_analog_out(analog_out::out1,0);
	_parser_conf = parser_conf_t::verbose;
	if( _parser_conf == parser_conf_t::verbose )
	{
		auto str = " > reset";
		uart_tx_send(str,strlen(str));
	}
    return false;
}
bool conf(const char* arg,uint32_t len)
{
	if( uart_tx_busy() && (_parser_conf == parser_conf_t::verbose) )
		return true;
	if( len == 0 )
		return false;
	if( strncmp(arg,"verbose",len) == 0 )
	{
		_parser_conf = parser_conf_t::verbose;
		if( _parser_conf == parser_conf_t::verbose )
		{
			auto str = " > conf verbose";
			uart_tx_send(str,strlen(str));
		}
		return false;
	}
	if( strncmp(arg,"quiet",len) == 0 )
	{
		_parser_conf = parser_conf_t::quiet;
		return false;
	}
	if( auto split = strnsplit(arg,len,' ') )	//autoread
	{
		//	if( _parser_conf == parser_conf_t::autoread )
		auto[ch,ch_len,val,val_len] = split.value();
		if( strncmp(ch,"autoread",8) == 0 )
		{
			if( is_numn(val,val_len) )
			{
				if( val_len > 6 )
					val_len = 6;
				_autoread_dt = atoin(val,val_len);
				_autoread_tim.restart();
				_parser_conf = parser_conf_t::autoread;
				return false;
			}
		}
		return false;
	}
	return false;
}
bool help(const char* arg,uint32_t len)
{
	const char help[] =R"=====( > help:
'read dioX'    with X=[0:3]
'read diX'     with X=[0:3]
'read anX'     with X=[0:1]
'write dioX V' with X=[0:3],V=[0:1]
'write doX V'  with X=[0:4],V=[0:1]
'write anX V'  with X=[0:1],V=[0.0:100.0]
'reset'        write zero to all analog an digital
'conf X'       with X=[verbose|quiet|autoread T],T=[0:999999]
               T is the acquisition period (in ms)
'help'         print this)=====";
	if( uart_tx_busy() )
		return true;
	uart_tx_send(help,sizeof(help));
    return false;
}
void autoread_task()
{
	if( _autoread_tim >= _autoread_dt && _parser_conf == parser_conf_t::autoread )
	{
		_autoread_tim.stop();
		if( uart_tx_busy() )
			return;
		char str[32];
		uint32_t str_len;
		read_all_io(str,&str_len);
		uart_tx_send(str,str_len);
		_autoread_tim.restart();
	}
}
static void read_all_io(char* str,uint32_t* str_len)
{
	sprintf(str,"%.2f %.2f %.2f %.2f ",
			read_analog_in(analog_in::in0),
			read_analog_in(analog_in::in1),
			read_analog_out(analog_out::out0),
			read_analog_out(analog_out::out1));
	static union
	{
		struct
		{
			uint8_t in0 : 1;
			uint8_t in1 : 1;
			uint8_t in2 : 1;
			uint8_t in3 : 1;
			uint8_t rsv : 3;
			uint8_t msb : 1;
		};
		uint8_t raw;
	}digital_in;
	digital_in.in0 = read_digital_in(digital_in::in0);
	digital_in.in1 = read_digital_in(digital_in::in1);
	digital_in.in2 = read_digital_in(digital_in::in2);
	digital_in.in3 = read_digital_in(digital_in::in3);
	digital_in.msb = true;	//to asure that the byte is non zero

	static union
	{
		struct
		{
			uint8_t io_in0 : 1;
			uint8_t io_in1 : 1;
			uint8_t io_in2 : 1;
			uint8_t io_in3 : 1;
			uint8_t rsv : 3;
			uint8_t msb : 1;
		};
		uint8_t raw;
	}digital_io_in;
	digital_io_in.io_in0 = read_digital_in(digital_in::io_in0);
	digital_io_in.io_in1 = read_digital_in(digital_in::io_in1);
	digital_io_in.io_in2 = read_digital_in(digital_in::io_in2);
	digital_io_in.io_in3 = read_digital_in(digital_in::io_in3);
	digital_io_in.msb = true;	//to asure that the byte is non zero

	static union
	{
		struct
		{
			uint8_t out0 : 1;
			uint8_t out1 : 1;
			uint8_t out2 : 1;
			uint8_t out3 : 1;
			uint8_t out4 : 1;
			uint8_t rsv  : 2;
			uint8_t msb  : 1;
		};
		uint8_t raw;
	}digital_out;
	digital_out.out0 = read_digital_out(digital_out::out0);
	digital_out.out1 = read_digital_out(digital_out::out1);
	digital_out.out2 = read_digital_out(digital_out::out2);
	digital_out.out3 = read_digital_out(digital_out::out3);
	digital_out.out4 = read_digital_out(digital_out::out4);
	digital_out.msb = true;	//to asure that the byte is non zero

	static union
	{
		struct
		{
			uint8_t io_out0 : 1;
			uint8_t io_out1 : 1;
			uint8_t io_out2 : 1;
			uint8_t io_out3 : 1;
			uint8_t rsv : 3;
			uint8_t msb : 1;
		};
		uint8_t raw;
	}digital_io_out;
	digital_io_out.io_out0 = read_digital_out(digital_out::io_out0);
	digital_io_out.io_out1 = read_digital_out(digital_out::io_out1);
	digital_io_out.io_out2 = read_digital_out(digital_out::io_out2);
	digital_io_out.io_out3 = read_digital_out(digital_out::io_out3);
	digital_io_out.msb = true;	//to asure that the byte is non zero

	*str_len = strlen(str);
	str[(*str_len)++] = digital_in.raw;
	str[(*str_len)++] = digital_io_in.raw;
	str[(*str_len)++] = digital_out.raw;
	str[(*str_len)++] = digital_io_out.raw;
	str[*str_len] = '\0';
}

}//namespace wte
