/*
 * hardwarecallbacks.h
 *
 *  Created on: May 31, 2023
 *      Author: Damian
 */

#pragma once

#ifdef __cplusplus
extern "C"{
#endif

#include "usart.h"
#include "adc.h"

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart);
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);

#ifdef __cplusplus
}
#endif
