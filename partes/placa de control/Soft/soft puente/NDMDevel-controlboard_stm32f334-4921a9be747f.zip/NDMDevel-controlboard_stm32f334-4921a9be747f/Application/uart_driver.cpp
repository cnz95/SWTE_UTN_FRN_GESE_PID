/*
 * uart_driver.cpp
 *
 *  Created on: May 30, 2023
 *      Author: Damian
 */

#include "uart_driver.h"
#include "FifoBuffer.hpp"
#include <cstdint>
#include <cstring>
#include "usart.h"
#include "utils.h"
//#include "sml_v1.1.6.hpp"

namespace wte
{

//private vars

//rx frame related
static constexpr char _EOF = '\r';
static mcu::FifoBuffer<uint8_t,uint8_t,16> _uart_rx_buffer;
static uint8_t _rx_data;
static struct command_t
{
	static constexpr uint8_t len = 32;
	char data[len];
	uint8_t idx = 0;
}_command;

//tx related
static struct tx_buffer_t
{
	std::array<uint8_t,512> data;
	bool busy = false;

}_uart_tx_buffer;

//state machine related
static enum class state_t
{
	shutdown,
	init,
	read_frame,
	process_frame,
	find_command,
	invoke_processor,
	ignore_and_wait_eof
}_st = state_t::shutdown;
static bool shutdown_programmed = false;

//command processor related
static constexpr uint32_t invalid_index = -1;
static const command_metadata_t* 	_command_info 		= nullptr;
static uint32_t 					_command_info_len 	= 0;
static uint32_t 					_command_info_idx 	= invalid_index;
static struct
{
	const char* value;
	uint32_t 	len;
	void set(const char* _arg,uint32_t _len)
	{
		if( _arg == nullptr || len == 0 )
			reset();
		else
		{
			value 	= _arg;
			len 	= _len;
		}
	}
	void reset()
	{
		value 	= nullptr;
		len 	= 0;
	}
}_processor_arg,_command_name;

//private functions
static void uart_start_rx()
{
	HAL_UART_Receive_IT(&huart2,&_rx_data,1);
}
static void uart_stop_rx()
{
	HAL_UART_AbortReceive_IT(&huart2);
}

//build with using <cstring>
//22580	     28	   2092	  24700
/*
namespace sml = boost::sml;

struct state_machine
{
	//events
	struct loop {};

	//state machine state flow
	auto operator()() const {
	//guards
	const auto rxEmpty 			= []{ return _uartRxBuffer.isEmpty(); };
	const auto commandFull		= []{ return _command.len >= _command.idx; };

	//actions
	const auto clearCommand 	= []{ _command.idx = 0; };

    using namespace sml;
    return make_transition_table(
*"read_frame"_s	+ event<loop> 	[ rxEmpty  ]						= "read_frame"_s
,"read_frame"_s	+ event<loop>	[ commandFull ] /
    );
  }
};*/

//public functions
void uart_rx_init(const command_metadata_t* info,uint32_t len)
{
	_command_info 	  = info;
	_command_info_len = len;
	if( _command_info == nullptr || _command_info_len == 0 )
		shutdown_programmed = true;
	else
	{
		shutdown_programmed = false;
		if( _st == state_t::shutdown )
		{
			uart_start_rx();
			_st = state_t::init;
		}
	}
}
void uart_rx_task()
{
	if( _st != state_t::invoke_processor && shutdown_programmed )
	{
		_st = state_t::shutdown;
		uart_stop_rx();
		shutdown_programmed = false;
		return;
	}
	if( _st == state_t::shutdown )
		return;
	if( _st == state_t::init )
	{
		_command.idx = 0;
		_st = state_t::read_frame;
		return;
	}
	if( _st == state_t::read_frame )
	{
		if( _uart_rx_buffer.isEmpty() )
			return;
		if( _command.idx >= _command.len )
		{
			_st = state_t::ignore_and_wait_eof;
			return;
		}
		auto data = _uart_rx_buffer.get();
		if( data == _EOF )
		{
			_command.data[_command.idx] = '\0';
			_st = state_t::process_frame;
			return;
		}
		_command.data[_command.idx++] = data;
		return;
	}
	if( _st == state_t::process_frame )
	{
		if( auto split=strsplit(_command.data,' ') )
		{
			//the frame received has this format:
			//"command 123\0"
		    std::tie(_command_name.value,
		             _command_name.len,
		             _processor_arg.value,
		             _processor_arg.len) = split.value();
		}
		else
		{
			//the frame received has this format:
			//"command\0"
			_command_name.value = _command.data;
			_command_name.len   = _command.idx;
			_processor_arg.reset();
		}
		_st = state_t::find_command;
		return;
	}
	if( _st == state_t::find_command )
	{
		_command_info_idx = invalid_index;
		for( uint32_t i=0 ; i<_command_info_len ; i++ )
			if( strncmp(_command_info[i].name,_command_name.value,_command_name.len) == 0 )
			{
				_command_info_idx = i;
				break;
			}
		if( _command_info_idx == invalid_index )
		{
			//command not found, reset task
			_st = state_t::init;
			return;
		}
		//the command was found, now invoke the processor
		_st = state_t::invoke_processor;
		return;
	}
	if( _st == state_t::invoke_processor )
	{
		if( _command_info[_command_info_idx].processor(_processor_arg.value,_processor_arg.len) )
			return;
		_st = state_t::init;
		return;
	}
	if( _st == state_t::ignore_and_wait_eof )
	{
		if( _uart_rx_buffer.isEmpty() )
			return;
		auto data = _uart_rx_buffer.get();
		if( data == _EOF )
			_st = state_t::init;
		return;
	}
}
void uart_rx_reception()
{
	_uart_rx_buffer.put(_rx_data);
	uart_start_rx();
}
bool uart_tx_busy()
{
	return _uart_tx_buffer.busy;
}
void uart_tx_send(const char* data,uint32_t len)
{
	if( _uart_tx_buffer.busy )
		return;
	for( uint32_t i=0 ; i<len ; i++ )
		_uart_tx_buffer.data[i] = data[i];
	_uart_tx_buffer.data[len] = '\n';
	_uart_tx_buffer.busy = true;
	HAL_UART_Transmit_IT(&huart2, _uart_tx_buffer.data.data(), len+1);
}
void uart_tx_completed()
{
	_uart_tx_buffer.busy = false;
}

}//namespace wte
