/*
 * utils.h
 *
 *  Created on: Jun 1, 2023
 *      Author: Damian
 */

#pragma once

#include <optional>
#include <cstring>
#include <tuple>
#include <cstdint>

template<typename T>
std::optional<std::tuple<T,uint32_t,T,uint32_t>> strsplit(T src,char separator)
{
    if( auto sep = strchr(src,separator); sep != nullptr )
    {
        T str1 = src;
        uint32_t len1 = uint32_t(sep - src);

        T str2 = sep+1;
        uint32_t len2 = strlen(str2);
        return {{str1,len1,str2,len2}};
    }
    return std::nullopt;
}

template<typename T>
std::optional<std::tuple<T,uint32_t,T,uint32_t>> strnsplit(T src,uint32_t n,char separator)
{
	const auto strnchr = [](T str,uint32_t n,char token) -> T
	{
		if( n == 0 || str == nullptr )
			return nullptr;
		for( uint32_t i=0 ; i<n ; i++ )
			if( str[i] == token)
				return str+i;
		return nullptr;
	};
    if( auto sep = strnchr(src,n,separator); sep != nullptr )
    {
        T str1 = src;
        uint32_t len1 = uint32_t(sep - src);

        T str2 = sep+1;
        uint32_t len2 = strlen(str2);
        return {{str1,len1,str2,len2}};
    }
    return std::nullopt;
}

/*
 * For atofn, credits to: https://stackoverflow.com/a/67521458/2538072
 */
float atofn(const char* arr,uint32_t n);
int atoin(const char* str,uint32_t n);
bool is_numn(const char* arr,uint32_t n);
bool is_alfanumn(const char* arr,uint32_t n);
