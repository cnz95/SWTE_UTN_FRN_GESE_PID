/*
 * double_buffer.h
 *
 *  Created on: May 30, 2023
 *      Author: Damian
 */

#pragma once

#include <array>

/** @brief Provides a double buffer functionality
 *
 * Main concepts:
 * - busy buffer
 * - ready buffer
 *
 * The busy buffer is the one being used by a third party and its
 * content may change at any time (for instance, from an interrupt or DMA access),
 * this means that the content of this buffer must be considered as invalid (because
 * is about to change).
 *
 * The ready buffer is the one that holds valid data (because it is not currently in use).
 *
 * There are five methods:
 * - T*		busy_buffer():		returns pointer to the busy buffer
 * - T*		ready_buffer(): 	returns pointer to the ready buffer
 * - void	switch_buffer(): 	switch the buffers (after invoking
 * 							 	this method, the busy buffer will
 * 							 	become ready buffer and biceversa)
 * - T		read():				reads the value held by ready buffer
 * 								in a non atomic way, this means that
 * 								the read may fail (return invalid data)
 * 								if read() is interrupted by hardware and
 * 								the buffer is switched and a new value
 * 								is store in it. This is very unlikely,
 * 								although not imposible.
 * - T		atomic_read():		reads the ready buffer in the atomic way
 * 								(first disable the interrupts, then read
 * 								the buffer, and finally enable the interrupts
 * 								again). This method is only available if
 * 								the user provides as a templated argument
 * 								a function pointer that enable/disable the
 * 								interrupts (the function pointer receives
 * 								a boolean indicating if the interrupt must be
 * 								enable <boolean == true> or disable <boolean == false>).
 */
template<typename T,void(*t_isr_enable_disable)(bool) = nullptr>
class double_buffer_t
{
public:
	double_buffer_t()
		: _buff({0,0})
		, _using_first(true) {}
	T* 			busy_buffer()			{ return _using_first? &_buff[0]:&_buff[1]; }
	T* 			ready_buffer()			{ return _using_first? &_buff[1]:&_buff[0]; }
	const T* 	busy_buffer()	const 	{ return _using_first? &_buff[0]:&_buff[1]; }
	const T* 	ready_buffer()	const 	{ return _using_first? &_buff[1]:&_buff[0]; }
	void		switch_buffer()			{ _using_first = !_using_first; }
    T 		 	read() 			const 	{ return *ready_buffer(); }
	T 		 	atomic_read() 	const
	{
		static_assert(t_isr_enable_disable!=nullptr,
					  "t_isr_enable_disable(bool) is required to disable and enable the interrupts before and after access the data.");
        t_isr_enable_disable(false);
        auto val = read();
        t_isr_enable_disable(true);
        return val;
	}
private:
	std::array<T,2> _buff;
	bool _using_first;
};

