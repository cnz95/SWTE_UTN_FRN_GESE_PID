/*
 * GUARDA: esta versi�n es solo para realizar todos los cambios que requiera implementar el proceso de simulaci�n con
 * todo el hardware real (conexion con la PC durante la simulaci�n, control de la consigna del variador, prueba con
 * uno o m�s valores fijos de cargas en el generador)
 * -> todos los cambios est�n relacionados a esto
 * -> el resto del c�digo y comentarios se mantiene para poder retormar f�cilmente la versi�n anterior
 * en caso de ser necesario
 * 
 * -> el flag iniCurva qued� al dope porque no lo us� m�s en la parte ascendente, una vez que entra en r�gimen permanente,
 * al salirse, el torque se va para arriba
 * -> tambi�n coment� el c�digo que bajaba el torque de golpe cuando pas�bamos a una curva con un m�ximo menor al nivel actual
 * de consigna, parece que estaba para alguna caracter�stica que al final no qued� en el algoritmo
 * 
 * 
 * ////////////////////////////// a partir de ac� los comentarios son de la versi�n anterior //////////////////////////////
 * 
 * 
 * 
 * se implement� el c�digo necesario para el "indicador de r�gimen permanente alcanzado"(un led p/el usuario y un msj p/la PC)
 * 
 * se realiz� una modificaci�n en las "condiciones que generan cambios en la simulaci�n de la curva actual", el c�digo de las
 * condiciones que resultan en la finalizaci�n de la simulaci�n pasan el control al estado INIC_SIM_TURB y fuerzan la
 * condici�n k > c_iCurvas (de esta manera solo se finaliza la simulaci�n pasando por esa condici�n (menor probabilidad de
 * errores de programaci�n, c�digo m�s ordenado, pr�cticamente igual en memoria de programa))
 *  * para forzar la cond. se asign� k = 254, por lo que solo es posible implementar la simulaci�n de una c_iCurva menor a 255
 *    (xq k = 255 debe producir siempre la finalizaci�n de la simulaci�n)-> igual siempre debi� ser as� xq si hay 255 curvas
 *    al ingresar nuevamente se incrementa en uno y desborda, volviendo al valor inicial de cero
 * 
 * se salv� la posibilidad de un error en el uso del TMR2 en la correspondiente interrupci�n (verificaci�n de estado)
 * 
 * se estandariz� los par�metros pasados a la funci�n error en cada caso
 * 0x00 -> error de programaci�n (no deber�a ocurrir)
 * 0x0F -> error en la integridad de los datos recibidos -> recepci�n de datos de turbina
 * 0x1F -> error en la integridad de los datos recibidos -> recepci�n de caracter�sticas de simulaci�n
 * 0xF0 -> error de NO respuesta de la PC o respuesta incoherente -> recepci�n de datos de turbina
 * 0xF1 -> error de NO respuesta de la PC o respuesta incoherente -> recepci�n de caracter�sticas de simulaci�n
 * 0xF2 -> error de NO respuesta de la PC o respuesta incoherente -> interrupci�n del TMR2
 * 0xE2 -> error de comunicaci�n incoherente de la PC -> interrupci�n del m�dulo UART
 * (en todos los casos el otro par�metro es el valor err�neo)
 * 
 * se elimin� el uso de los mensajes de FIN_SIM_PROC y FIN_CURVA_PROC (tambi�n se sac� del c�digo en matlab)
 * xq la PC no realiza un control sobre el correcto funcionamiento del uC (tampoco podr�a tomar medidas si lo hiciera)
 * 
 * 
 * Trabajos futuros necesarios:
 * - agregar la activaci�n y desactivaci�n de las interrupciones de TMR2 y UART_RX  (REQUIERE VER EN LA IMPLEMENTACI�N REAL)
 *   -> TMR2: activar cada vez que se arranca una simulaci�n y desactivar cada vez que se finaliza
 *      (cuando se enciende y se apaga el motor, respectivamente)
 *   -> UART_RX: activar cuando se sale del estado CONFIG_SIM y desactivar cuando se ingresa (activo en todos los otros)
 * - evaluar si es m�s pr�ctico el env�o de un msj mientras se est� en estado estable o solo informar cambios
 *   (PUEDE SER NECESARIO VER EN LA IMPLEMENTACI�N REAL ? )
 * - evaluar si es necesaria una espera cuando se haga consigna = torque_max en el estado INIC_SIM_TURB
 *  (REQUIERE VER EN LA IMPLEMENTACI�N REAL)
 * - determinar si es conveniente separar en 2 estado la carga de los datos de la simulaci�n para poder cambiar los �ndices
 *   y la cantidad de curvas a simular sin tener que volver a cargar la tabla (depende del tiempo que lleve ese proceso)
 *   (REQUIERE VER EN LA IMPLEMENTACI�N REAL - SOLO PLACA)
 * - comprobar la desviaci�n del valor ideal del "periodo de actualizaci�n de la consigna" que resulta en la pr�ctica
 *   (REQUIERE VER EN LA IMPLEMENTACI�N REAL - SOLO PLACA)
 * 
 * - configuraci�n y operaci�n de TMR para periodo de actualizaci�n de la consigna ??? 
 * - queda para el ajuste "final" el uso del TMR2 para evitar que se cuelgue el uC
 *   (solo cuando el motor se encuentra en funcionamiento)
 * - implementar y llamar funciones para y en los punto marcados con:
 *   - // indicador de r�gimen permanente alcanzado
 * 
 * - cambiar el punto donde se baja el indicador de r�gimen permanente alcanzado en caso de que resulte visible el parpadeo
 * 
 * 
 * POSIBLES CAMBIOS FUTUROS
 * - se podr�a usar la fc error que puede diferenciar los casos m�s leves entre los que se puede enviar un mensaje a la PC,
 *   esperar la respuesta, y reiniciar/continuar el proceso que se estaba realizando, en caso de ser posible
 * - informar a la PC los errores de "NO respuesta de la PC" y "en la integridad de los datos recibidos" ???
 *   -> el primero no parece pr�ctico xq si la PC no responde es muy probable que no reciba nada
 *      y si lo recibe no es posible asegurar que sea capaz de procesarlo
 *   -> el segundo ya lo deber�a suponer la PC si se le envi� 3 mensajes de error en los datos
 */

// CONFIG1
#pragma config FOSC = INTOSC    // Oscillator Selection Bits (INTOSC oscillator: I/O function on CLKIN pin)
#pragma config PWRTE = OFF      // Power-up Timer Enable (PWRT disabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select (MCLR/VPP pin function is MCLR)
#pragma config CP = OFF         // Flash Program Memory Code Protection (Program memory code protection is disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable (Brown-out Reset enabled)
#pragma config CLKOUTEN = OFF   // Clock Out Enable (CLKOUT function is disabled. I/O or oscillator function on the CLKOUT pin)
#pragma config IESO = ON        // Internal/External Switch Over (Internal External Switch Over mode is enabled)
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable (Fail-Safe Clock Monitor is enabled)

// CONFIG2
#pragma config WRT = OFF        // Flash Memory Self-Write Protection (Write protection off)
#pragma config PPS1WAY = ON     // Peripheral Pin Select one-way control (The PPSLOCK bit cannot be cleared once it is set by software)
#pragma config ZCD = OFF        // Zero Cross Detect Disable Bit (ZCD disable.  ZCD can be enabled by setting the ZCDSEN bit of ZCDCON)
#pragma config PLLEN = OFF      // PLL Enable Bit (4x PLL is enabled when software sets the SPLLEN bit)
#pragma config STVREN = ON      // Stack Overflow/Underflow Reset Enable (Stack Overflow or Underflow will cause a Reset)
#pragma config BORV = LO        // Brown-out Reset Voltage Selection (Brown-out Reset Voltage (Vbor), low trip point selected.)
#pragma config LPBOR = OFF      // Low-Power Brown Out Reset (Low-Power BOR is disabled)
#pragma config LVP = ON         // Low-Voltage Programming Enable (Low-voltage programming enabled)

// CONFIG3
#pragma config WDTCPS = WDTCPS1F// WDT Period Select (Software Control (WDTPS))
#pragma config WDTE = OFF       // Watchdog Timer Enable (WDT disabled)
#pragma config WDTCWS = WDTCWSSW// WDT Window Select (Software WDT window size control (WDTWS bits))
#pragma config WDTCCS = SWC     // WDT Input Clock Selector (Software control, controlled by WDTCS bits)

#include <xc.h>
#include <stdint.h>
#include "config.h"
#include "fcs_variador.h"
#include "fcs_uart.h"
#include "fcs_aux.h"

#define _XTAL_FREQ 4000000

// constantes de posibles estados
#define EST_CONFIG_SIM      0xE1	// configurando simulaci�n
#define EST_INIC_SIM_TURB	0xE2	// incializaci�n simulaci�n turbina
#define EST_SIM_TURB        0xE3	// simulando turbina
#define EST_ESPERA_COM      0xE4    // esperando comunicaci�n


#define EST_PRUEBA          0xE0    // estado auxiliar para realizar pruebas


// constantes de mensajes para coordinaci�n (UART)
#define MSJ_ESPERA_DATOS    0xF1    // esperando datos
#define MSJ_ESTAS_AHI       0xEA    // consulta a PC, verificaci�n presencia (est�s ah�?"/"ac� estoy")
#define MSJ_ACA_ESTOY       0xAE    // respuesta PC, verificaci�n presencia (est�s ah�?"/"ac� estoy")
#define	MSJ_ERROR           0xEE    // error //// HASTA EL MOMENTO NO SE UTILIZA ////
#define MSJ_DATOS_OK        0xDF    // CRC de datos correcto
#define MSJ_DATOS_ERROR     0xD0    // CRC de datos incorrecto
#define MSJ_FIN_CURVA       0xFC    // indicaci�n para finalizar simulaci�n de curva actual
#define MSJ_FIN_SIM         0xF5    // indicaci�n para finalizar/detener simulaci�n completa
#define MSJ_NO_EXISTE_CRUCE 0x0C    // no se encontr� cruce con curva
#define MSJ_FIN_CURVA_PROC  0xC9    // finCurva procesado correctamente //// HASTA EL MOMENTO NO SE UTILIZA ////
#define MSJ_TORQ_CONS_DIF   0xED    // error: diferencia excesiva entre torque le�do y consigna
#define MSJ_OMEGA_SUP_MAX2  0x55    // error: segundo umbral m�ximo de omega superado
#define MSJ_FIN_SIM_PROC    0x59    // finSim procesado correctamente //// HASTA EL MOMENTO NO SE UTILIZA ////
#define MSJ_REG_PERM        0xA9    // r�gimen permanente alcanzado
#define MSJ_REG_TRAN        0xA1    // r�gimen permanente NO alcanzado (r�gimen transitorio)

// constantes de mensajes para inicio de secuencia de datos (UART)
#define DATOS_TURB	0xD1	// secuencia de datos de turbina
#define CARACT_SIM	0xD2	// secuencia de caracter�sticas de la simulaci�n

// constantes de tipos de simulaci�n
#define SIM_CURVA_UNICA 0xC1	// simulaci�n de una curva
#define SIM_FAMIL_CURVA	0xC2	// simulaci�n de familiza de curvas

// constantes de cantidad de filas y columnas de la tabla
#define	CANT_F	13
#define	CANT_C	14

// constante de cantidad de bytes de cada elemento de la tabla
#define CANT_BYTES_ELEM 1

// constante de error m�ximo en el valor detectado de omega (omega = omega0 +- omega_error_max)
#define OMEGA_ERROR_MAX 2

// constante de error m�ximo en el valor detectado de torque (torque_max_real = torque_max_ideal + torque_error_max)
#define TORQUE_ERROR_MAX 8
//// parece que el ruido complica las cosas

// constante de paso de ajuste de la consigna (incremento/decremento))
#define PASO_AJUSTE_CONSIGNA 1
// al momento de implementar los estados se consider� que esta constante ser�a <= 2

// constante del periodo de actualizaci�n de la consigna (en milisegundos)
//#define PERIODO_ACT_CONS_MS 250 // 40 d� 10 segs para llegar a 255
#define PERIODO_ACT_CONS_MS 40
#define PERIODO_ACT_CONS_RP_MS 100

// constante de espera ante un cambio brusco de consigna, para alcanzar una velocidad estable 
#define ESPERA_CAMBIO_CONS_MS 10000

/* 
 * Nota: LAS �LTIMAS CONSTANTES SIMB�LICAS SON AJUSTABLES, PERO DEBER�A CONSIDERARSE LO SIGUIENTE:
 * TORQUE_ERROR_MAX >= PASO_AJUSTE_CONSIGNA
 * OMEGA_ERROR_MAX ~ TORQUE_ERROR_MAX
 * PERIODO_ACT_CONS_MS -> 255*PERIODO_ACT_CONS_MS = t max para variaci�n de consigna (~ 10 a 30 segs)
 * ESPERA_CAMBIO_CONS_MS >= al tiempo de desaceleraci�n del variador
 * 
 * -> OMEGA_ERROR_MAX y TORQUE_ERROR_MAX tambi�n dependen de la magnitud de la desviaci�n que pueden presentar las lecturas
 *    de omega y torque, respectivamente
 * -> ESPERA_CAMBIO_CONS_MS solo ser�a mayor que el tiempo de desaceleraci�n para darle un margen de error, porque con
 *    igualar ese tiempo es suficiente
*/

// prototipo de funci�n error
void Error(uint8_t dato0, uint8_t dato1);

// prototipo de funci�n con el vector de interrupciones
void interrupt rsi(void);


// matriz p/ los valores de la tabla (vel de viento, omega, torque)
uint8_t tabla[CANT_F][CANT_C];
// * es global porque en la fc main las vars est�n limitadas a 80 bytes
// * la cant. de bits de cada elem. depende de la resoluci�n del m�todo usado
// en la lectura del torque y el omega (conversi�n float-entero en la PC)
// * las filas y columnas se invierten con respecto a la tabla de la PC, para
// trabajar de forma m�s c�moda los punteros.

// variable de estado actual
uint8_t estado = EST_ESPERA_COM;
// var global porque se utiliza durante la interrupci�n del TMR2 (verificaci�n de presencia)

// indicadores de "fin de simulaci�n" y "fin de curva", para detener la simulaci�n completa o de una curva en particular
uint8_t finSim, finCurva;
// var global porque se utilizan durante la interrupci�n del RX_UART

uint8_t v_iCurva[256], c_iCurva;

void main(void)
{
    configUC();
    
    configADC();
    
    configDAC();
    
    configUART();
	
	configTMR0();
    
    configTMR2();
    
    configCRC8();
    
    uint8_t *torque_curva; // puntero para vector de valores de torque (ordenada)
    uint8_t *omega_curva; // puntero para vector de valores de omega (abscisa)
    uint8_t bufferRx[CANT_BYTES_ELEM]; // vector de elementos recibidos (por el momento se utiliza un solo elemento)
	uint8_t f, c;	// vars auxs para valor de fila y columna
	uint8_t torque, omega, torque_min, omega_min, torque_max, omega_max, consigna; // vars de:
    // valores medidos, maxs y mins de la tabla (de torque y omega) y consigna (asignable a torque o a omega, en teor�a jeje)
    uint8_t est_omega, est_torque; // var aux, para evaluar conds con anterioridad para que el c�digo resulte claro
    uint8_t omega1, omega2; // valores de omega en los cruces de la curva con el valor medido de torque
    uint8_t i, j, k; // vars auxs p/bucles
    uint8_t CRC, vCRC[CANT_F]; // CRC calculado, vector de CRC recibidos
    uint8_t c_fallas; // contador de veces que se produjo detect� un error en la recepci�n de datos de la simulaci�n
    //uint8_t v_iCurva[CANT_F], c_iCurva; // vector de �ndices de las curvas a simular, cantidad de elem's �tiles del vector
    //uint8_t v_iCurva[256], c_iCurva; // se hizo global por el espacio
    uint8_t falla_interp_1, falla_interp_2; // indicadores de falla en la determinaci�n de omega1 y omega 2, respectivamente
    // (falla: cuando no est� definido un valor de omega1 u omega2 para el valor medido de torque)
    uint8_t iniCurva; // indicador de inicio de simulaci�n de una nueva curva (salva error de iniciar la nueva curva con un
    // torque mayor al del pto del cruce entre la curva de carga y la curva de la turbina)
    uint8_t msj = 0; // var que almacena el mensaje que se debe enviar a la PC, es cero si no se debe enviar nada
    uint8_t prim_ingr_esp_com = 1; // indicador de primer ingreso al estado ESPERA_COM
    uint8_t dif_tmax_cons;
    
    consigna = 0; // por seguridad
    
    // PRUEBA
                        for( f = 0 ; f < CANT_F ; f++ ) //recorrer filas
                        {
                            for( c = 0 ; c < CANT_C ; c++ ) // recorrer columnas
                            {
                                tabla[f][c] = 0;
                            }
                        }
    // PRUEBA
    //// PRUEBA ////
    uint8_t msj2;
    uint8_t msj3;
    uint8_t msj4;
    //// PRUEBA ////
    
    
	while(1)
	{
        
		switch(estado)
		{
			case EST_CONFIG_SIM:
                
                motor_detener();
                
                // se desactivan las dos interrupciones (TMR2 a modo de prevenci�n de errores en bus de datos)
                PIE1bits.RCIE = 0; // ac� hay recepci�n de datos y ser�a un error que actuara la interrupci�n
                
                c_fallas = 0;
                f = 255;
                
                enviarUART(MSJ_ESPERA_DATOS);
                bufferRx[0] = recibirUART();
                
                if(bufferRx[0] == DATOS_TURB)
                {
                    while( (f == 255) && (c_fallas < 3) ) // f==255 es un artilugio algor�tmico jajaja
                    {
                        for( f = 0 ; f < CANT_F ; f++ ) //recorrer filas
                        {
                            for( c = 0 ; c < CANT_C ; c++ ) // recorrer columnas
                            {
                                // esto est� generalizado al caso de que se reciban datos de m�s de un byte (mayor resoluci�n)
                                for(i = 0 ; i < CANT_BYTES_ELEM ; i++ )
                                {
                                    // recibir datos
                                    bufferRx[i] = recibirUART();
                                }
                                // almacenar valor en tabla
                                tabla[f][c] = *bufferRx;	// se recibe 1 byte
                                
                            }
                            // guardar CRC en vector vCRC (se recibe 1 por cada fila)
                            vCRC[f] = recibirUART();
                        }
                        
                        // evaluar integridad de datos mediante CRC
                        for( f = 0 ; f < CANT_F ; f++ ) // recorrer las filas
                        {
                            // calcular CRC
                            CRC = calcCRC8( &(tabla[f][0]) , CANT_C );
                            if(CRC != vCRC[f]) // comparar CRC calculado con CRC recibido
                            {
                                f = 255; // break; -> se cambi� p/ que sea m�s claro el flujo del c�digo
                                c_fallas++; // incrementar contador de transmisi�nes fallidas
                                
                                enviarUART(MSJ_DATOS_ERROR); // informar error en los datos recibidos
                            }
                        }
                    }
                    
                    if(c_fallas < 3) // si no se sali� del bucle por fallas reiteradas
                    {
                        enviarUART(MSJ_DATOS_OK); // informar recepci�n correcta de datos
                        c_fallas = 0; 
                    }else
                    {
                        Error(bufferRx[0],0x0F); // error en la integridad de los datos recibidos
                    }
                }
                else
                {
                    Error(bufferRx[0],0xF0); // error de NO respuesta de la PC o respuesta incoherente
                }
                
                // continuar con los siguientes datos
                
                bufferRx[0] = recibirUART();
                f = 255;
                
                if(bufferRx[0] == CARACT_SIM)
                {
                    while( (f == 255) && (c_fallas < 3) ) // f==255 es un artilugio algor�tmico
                    {
                        // recibir cantidad de curvas a simular
                        c_iCurva = recibirUART();
                        
                        // recibir vector con los �ndices de las curvas
                        for( i = 0 ; i < c_iCurva ; i++ )
                        {
                            /////////////////////////////////////////////////////////////////////////
                            /////////////////////////////////////////////////////////////////////////
                            //// ac� hay un peque�o detalle, si el c_iCurva enviado no es valido ////
                            //// el micro puede intentar escribir y leer una posici�n de memoria fuera del vector ////
                            /////////////////////////////////////////////////////////////////////////
                            /////////////////////////////////////////////////////////////////////////
                            v_iCurva[i] = recibirUART();
                        }
                        // recibir CRC
                        vCRC[0] = recibirUART();
                        
                        // se incluye el dato de cantidad de curvas al final del vector de �ndices para calcular el CRC
                        v_iCurva[i] = c_iCurva;
                        
                        // evaluar la integridad de los datos mediante el CRC
                        CRC = calcCRC8( v_iCurva , c_iCurva+1 );
                        f = 0;
                        if(CRC != vCRC[0])
                        {
                            c_fallas++;
                            f = 255;
                            
                            enviarUART(MSJ_DATOS_ERROR);
                        }
                    }
                    
                    if(c_fallas < 3)
                    {
                        //enviarUART(MSJ_DATOS_OK);
                        
                        enviarUART(MSJ_DATOS_OK);
                        //enviarUART(MSJ_DATOS_OK); //// PRUEBA ////
                        //prim_ingr_esp_com = 1; //// PRUEBA ////
                    }
                    else
                    {
                        Error(bufferRx[0],0x1F); // error en la integridad de los datos recibidos
                    }
                }
                else
                {
                    Error(bufferRx[0],0xF1); // error de NO respuesta de la PC o respuesta incoherente
                }
                
                PIE1bits.RCIE = 1; // fuera de este estado debe actuar la interrupci�n
                
                estado = EST_ESPERA_COM; // cambiar a estado "esperando comunicaci�n"
                prim_ingr_esp_com = 1; // activar indicador de primer ingreso a estado ESPERA_COM
                
				break;
                
            case EST_INIC_SIM_TURB:
                
                k = k+1;
                
                if(k < c_iCurva ) // si a�n no se super� la cantidad de curvas a simular
                {
                    torque_curva = &(tabla[v_iCurva[k]+1][0]); // asignar el vector de la curva de torque correspondiente
                    iniCurva = 1; // inicializar flag de inicio de nueva curva
                    
                    if(k==0) // si es la primer curva de la simulaci�n
                    {
                        // asignar el vector de valores de omega
                        omega_curva = *tabla;
                        
                        finSim = 0; // inicializar indicador de fin de simulaci�n
                        TMR2 = 0; // reiniciar TMR2 (tiempo inactividad PC)
                        T2CONbits.ON = 1; // activar TMR2
                        consigna = 0; // por precauci�n para que el motor no comience a girar inmediatamente
                        escribirDAC_consigna(consigna);
                        
                        // bajar indicador de r�gimen permanente alcanzado
                        LATCbits.LATC3 = 0;
                        
                        // arrancar motor
                        motor_habilitar();
                        motor_girar_der();
                    }
                    
                    // identificar l�mites
                    omega_min = busq_min(omega_curva,CANT_C);
                    omega_max = busq_max(omega_curva,CANT_C);
                    torque_min = busq_min(torque_curva,CANT_C);
                    torque_max = busq_max(torque_curva,CANT_C);
                    
                    if(k!=0)
                    {
                        // comprobar que el valor de torque/consigna no producir� errores
                        /*if(torque > torque_max)
                        {
                            dif_tmax_cons = torque-torque_max;
                            consigna = torque_max;
                            escribirDAC_consigna(consigna);
                            //__delay_ms(ESPERA_CAMBIO_CONS_MS); // espera para alcanzar un omega estable
                            __delay_ms((uint8_t)(ESPERA_CAMBIO_CONS_MS*dif_tmax_cons/255)); // espera para alcanzar un omega estable
                        }*/
                    }
                    finCurva = 0; // inicializar indicador de "fin de simulaci�n de curva" para cada nueva curva
                    
                    estado = EST_SIM_TURB; // comenzar la simulaci�n propiamente dicha
                }
                else
                {
                    ///////////////////////////////////////////////////////////////////////////////////
                    ///////////////////////////////// esto no esta funcionando ////////////////////////
                    ///////////////////////////////////////////////////////////////////////////////////
                    /*while( consigna>PASO_AJUSTE_CONSIGNA )
                    {
                        __delay_ms(PERIODO_ACT_CONS_MS); // delay para ejecutar este c�digo cada cierto periodo (PERIODO_ACT_CONS_MS)
                        consigna -= PASO_AJUSTE_CONSIGNA;
                        escribirDAC_consigna(consigna);
                    }
                    //consigna -= PASO_AJUSTE_CONSIGNA
                    consigna = 0;
                    escribirDAC_consigna(consigna);
                    
                    T2CONbits.ON = 0; // desactivar TMR2
                    estado = EST_ESPERA_COM; // finalizar simulaci�n
                    prim_ingr_esp_com = 1; // activar indicador de primer ingreso a estado ESPERA_COM
                    */
                    
                    
                    __delay_ms(PERIODO_ACT_CONS_MS); // delay para ejecutar este c�digo cada cierto periodo (PERIODO_ACT_CONS_MS)
                    if(consigna > PASO_AJUSTE_CONSIGNA)
                    {
                        consigna -= PASO_AJUSTE_CONSIGNA;
                        escribirDAC_consigna(consigna);
                        k = 254; // forzar condici�n c_iCurvas superada (i>c_iCurvas), para finalizar simulaci�n
                    }
                    else
                    {
                        consigna = 0;
                        escribirDAC_consigna(consigna);
                        
                        T2CONbits.ON = 0; // desactivar TMR2
                        estado = EST_ESPERA_COM; // finalizar simulaci�n
                        prim_ingr_esp_com = 1; // activar indicador de primer ingreso a estado ESPERA_COM
                    }
                }
                
                break;
                
			case EST_SIM_TURB:
                
                // indicador de simulaci�n en curso
                LATCbits.LATC6 = 1;
                
                // b�sicamente cada vez que se pasa por este estado se redefine el valor de consigna seg�n la comparaci�n
                // del torque y omega medidos con las curvas especificadas en la tabla
                
                __delay_ms(PERIODO_ACT_CONS_MS); // delay para ejecutar este c�digo cada cierto periodo (PERIODO_ACT_CONS_MS)
                
                // leer valores de torque y omega indicados por el variador de velocidad
                torque = leerADC2_torque();
                omega = leerADC4_omega();
                
                // identificar en que rango de valores se encuentra omega
                est_omega = 3; // estado error
                if(T2CONbits.ON) // si se ingres� al estado INIC_SIM_TURB y se activ� el TMR2 correctamente
                {
                    if( (omega < omega_min-OMEGA_ERROR_MAX) || (omega==0) )
                    { // omega igual a cero salva el caso de que omegamin-error sea negativo
                        est_omega = 0;
                        iniCurva = 0; // bajar flag de curva inicial (no importa en estos casos)
                    }else
                    {
                        if( (omega > omega_max+OMEGA_ERROR_MAX) || (omega==255) )
                        { // omega igual a 255 salva el caso de que omegamax+error supere dicho n�mero
                            est_omega = 2;
                            iniCurva = 0; // bajar flag de curva inicial (no importa en estos casos)
                        }else
                        {
                            est_omega = 1;
                        }
                    }
                }
                
                // en la siguiente estructura se distinguen todas las posibles combinaciones de valores de omega y torque
                // y en funci�n de eso se determina el nuevo valor de la consigna (o se indica un error, si corresponde)
                switch(est_omega)
                {
                    case 0: // omega es menor al m�nimo
                        
                        // aumentar
                        consigna += PASO_AJUSTE_CONSIGNA;
                        
                        if(LATCbits.LATC3 == 1) // si no se desactiv� el indicador previamente
                        {
                            // bajar indicador de r�gimen permanente alcanzado
                            LATCbits.LATC3 = 0;
                            // asignar cadena de "r�gimen permanente NO alcanzado (r�gimen transitorio)"
                            msj = MSJ_REG_TRAN;
                            
                            //// PRUEBA ////
                            msj2 = consigna;
                            msj3 = torque;
                            msj4 = omega;
                            //// PRUEBA ////
                            
                        }
                        
                        break;
                        
                    case 1: // omega se encuentre entre el m�nimo y el m�ximo
                        
                        // determinar omega1 y omega2 a partir de la curva
                        
                        omega1 = 0; // inicializar variables
                        omega2 = 0; // inicializar variables
                        // encontrar el primer pto de la tabla m�s cercano al torque actual
                        for(i=0 ; (i<CANT_C) && (torque_curva[i+1]<=torque) && (torque_curva[i+1]>=torque_curva[i]) ; i++);
                        // i es el �ndice del torque de la tabla mas cercano anterior (menor o igual) al torque medido
                        
                        falla_interp_1 = 1;
                        falla_interp_2 = 1;
                        omega1 = 0;
                        omega2 = 255;
                        if(i<CANT_C) // si el bucle for se detuvo antes de llegar al final del vector
                        {
                            if(torque_curva[i+1]<torque_curva[i]) // i qued� en el pico (torque es superior a ese pto)
                            {
                                // asignar el valor del pico a omega1 y 2
                                omega1 = omega_curva[i];
                                omega2 = omega_curva[i];
                                falla_interp_2 = 0;
                                falla_interp_1 = 0;
                            }
                            else
                            {
                                if(torque>=torque_curva[i]) // si puede existir un cruce con la parte creciente de la curva
                                {
                                    // interpolar los puntos anterior y siguiente para encontrar omega1
                                    omega1 = interp(torque,torque_curva[i],torque_curva[i+1],omega_curva[i],omega_curva[i+1]);
                                    falla_interp_1 = 0;
                                }
                                // si no hay cruce con la curva queda omega1 = 0 y falla_interp_1 = 1
                                
                                // encontrar el primer pto de la tabla m�s cercano al torque actual
                                for(j=i ; (j<CANT_C) && (torque_curva[j+1]>torque) ; j++);
                                // j es el �ndice del torque de la tabla mas cercano anterior (mayor) al torque medido
                                
                                if(j<CANT_C-1) // si todo bien con el pto para el omega 2
                                {
                                    // interpolar los puntos anterior y siguiente para encontrar omega2
                                    omega2 = interp(torque,torque_curva[j],torque_curva[j+1],omega_curva[j],omega_curva[j+1]);
                                    falla_interp_2 = 0;
                                }
                                // si no hay cruce con la curva en su segmento queda omega2 = 255 y falla_interp_2 = 1
                            }
                        }
                        
                        if(omega < omega1 - OMEGA_ERROR_MAX) // si omega es menor a omega 1 y 2
                        {
                            // CAMBIO DEL ALGORITMO PARA EL CASO DE T > T_curva y Omega < Omega_curva
                            //if(iniCurva) // si se acaba de iniciar la simulaci�n de una nueva curva
                            if(1) // si se acaba de iniciar la simulaci�n de una nueva curva
                            {
                                // disminuir
                                if(consigna>PASO_AJUSTE_CONSIGNA)
                                {
                                    consigna -= PASO_AJUSTE_CONSIGNA;
                                }
                                
                                if(LATCbits.LATC3 == 1) // si no se desactiv� el indicador previamente
                                {
                                    // bajar indicador de r�gimen permanente alcanzado
                                    LATCbits.LATC3 = 0;
                                    // asignar cadena de "r�gimen permanente NO alcanzado (r�gimen transitorio)"
                                    msj = MSJ_REG_TRAN;
                                    
                                    //// PRUEBA ////
                                    msj2 = consigna;
                                    msj3 = torque;
                                    msj4 = omega;
                                    //// PRUEBA ////
                                    
                                }
                            }
                            else
                            {
                                // aumentar
                                consigna += PASO_AJUSTE_CONSIGNA;
                            }
                            if(LATCbits.LATC3 == 1) // si no se desactiv� el indicador previamente
                            {
                                // bajar indicador de r�gimen permanente alcanzado
                                LATCbits.LATC3 = 0;
                                // asignar cadena de "r�gimen permanente NO alcanzado (r�gimen transitorio)"
                                msj = MSJ_REG_TRAN;
                                
                                //// PRUEBA ////
                                msj2 = consigna;
                                msj3 = torque;
                                msj4 = omega;
                                //// PRUEBA ////
                                
                            }
                        }
                        
                        if( (omega <= omega1 + OMEGA_ERROR_MAX)&&(omega >= omega1 - OMEGA_ERROR_MAX) ) // si omega es "igual" a omega1 (dentro del margen de error considerado)
                        {
                            
                            if(falla_interp_1)
                            {
                                // aumentar
                                consigna += PASO_AJUSTE_CONSIGNA;
                                
                                if(LATCbits.LATC3 == 1) // si no se desactiv� el indicador previamente
                                {
                                    // bajar indicador de r�gimen permanente alcanzado
                                    LATCbits.LATC3 = 0;
                                    // asignar cadena de "r�gimen permanente NO alcanzado (r�gimen transitorio)"
                                    msj = MSJ_REG_TRAN;
                                    
                                    //// PRUEBA ////
                                    msj2 = consigna;
                                    msj3 = torque;
                                    msj4 = omega;
                                    //// PRUEBA ////
                                    
                                }
                            }
                            else
                            {
                                // =
                                if(LATCbits.LATC3 == 0) // si no se activ� el indicador previamente
                                {
                                    // indicador de r�gimen permanente alcanzado
                                    LATCbits.LATC3 = 1;
                                    // asignar cadena de "r�gimen permanente alcanzado"
                                    msj = MSJ_REG_PERM;
                                    
                                    //// PRUEBA ////
                                    msj2 = consigna;
                                    msj3 = torque;
                                    msj4 = omega;
                                    //// PRUEBA ////
                                    
                                }
                            }
                            iniCurva = 0; // bajar flag de curva inicial (no importa en estos casos)
                        }
                        if( (omega <= omega2 + OMEGA_ERROR_MAX) && (omega >= omega2 - OMEGA_ERROR_MAX) ) // si omega es "igual" a omega2 (dentro del margen de error considerado)
                        {
                            if(falla_interp_2)
                            {
                                // aumentar
                                consigna += PASO_AJUSTE_CONSIGNA;
                            }
                            else
                            {
                                // =
                                if(LATCbits.LATC3 == 0) // si no se activ� el indicador previamente
                                {
                                    // indicador de r�gimen permanente alcanzado
                                    LATCbits.LATC3 = 1;
                                    // asignar cadena de "r�gimen permanente alcanzado"
                                    msj = MSJ_REG_PERM;
                                    
                                    //// PRUEBA ////
                                    msj2 = consigna;
                                    msj3 = torque;
                                    msj4 = omega;
                                    //// PRUEBA ////
                                    
                                }
                            }
                            iniCurva = 0; // bajar flag de curva inicial (no importa en estos casos)
                        }
                        if( (omega > omega1 + OMEGA_ERROR_MAX) && (omega < omega2 - OMEGA_ERROR_MAX) ) // si omega se encuentre entre omega 1 y 2
                        {
                            // aumentar
                            consigna += PASO_AJUSTE_CONSIGNA;
                            
                            if(LATCbits.LATC3 == 1) // si no se desactiv� el indicador previamente
                            {
                                // bajar indicador de r�gimen permanente alcanzado
                                LATCbits.LATC3 = 0;
                                // asignar cadena de "r�gimen permanente NO alcanzado (r�gimen transitorio)"
                                msj = MSJ_REG_TRAN;
                                
                                //// PRUEBA ////
                                msj2 = consigna;
                                msj3 = torque;
                                msj4 = omega;
                                //// PRUEBA ////
                                
                            }
                            
                            iniCurva = 0; // bajar flag de curva inicial (no importa en estos casos)
                        }
                        if(omega > omega2 + OMEGA_ERROR_MAX) // si omega es mayor que omega 1 y 2
                        {
                            if(torque > torque_curva[CANT_C-1] + PASO_AJUSTE_CONSIGNA) // si no se "salt�" el l�mite inferior
                            {
                                // disminuir
                                consigna -= PASO_AJUSTE_CONSIGNA;
                            }
                            else
                            {
                                // asignar el m�nimo
                                consigna = torque_curva[CANT_C-1];
                            }
                            
                            if(LATCbits.LATC3 == 1) // si no se desactiv� el indicador previamente
                            {
                                // bajar indicador de r�gimen permanente alcanzado
                                LATCbits.LATC3 = 0;
                                // asignar cadena de "r�gimen permanente NO alcanzado (r�gimen transitorio)"
                                msj = MSJ_REG_TRAN;
                                
                                //// PRUEBA ////
                                msj2 = consigna;
                                msj3 = torque;
                                msj4 = omega;
                                //// PRUEBA ////
                                
                            }
                            
                            iniCurva = 0; // bajar flag de curva inicial (no importa en estos casos)
                        }
                        break;
                        
                    case 2: // omega es mayor al m�ximo
                        
                        if(torque >= torque_curva[CANT_C-1]) // si el pto de op se encuentra arriba de la curva
                        {
                            // disminuir
                            consigna -= PASO_AJUSTE_CONSIGNA;
                        }
                        break;
                        
                    default:
                        
                        Error(0,0); // solo es posible con un error en la programaci�n
                }
                
                // condiciones que generan cambios en la simulaci�n de la curva actual:
                
                // -> el torque supera el umbral m�ximo permitido
                // ||
                // -> la vel de giro supera el umbral m�ximo a la vez que el torque se encuentra por debajo del min de la
                //    parte decreciente de la curva
                if( (torque > torque_max + TORQUE_ERROR_MAX) || ( (omega > omega_max + OMEGA_ERROR_MAX) && (torque < torque_curva[CANT_C-1]) ) )
                {
                    // anular �ltimo aumento de la consigna
                    consigna -= PASO_AJUSTE_CONSIGNA;
                    // asignar cadena de "no se encontr� cruce con curva"
                    msj = MSJ_NO_EXISTE_CRUCE;
                    //// PRUEBA ////
                    msj2 = consigna;
                    msj3 = torque;
                    msj4 = omega;
                    //// PRUEBA ////
                }
                
                // -> se activ� el fin de curva
                if(finCurva == 1)
                {
                    estado = EST_INIC_SIM_TURB;
                    // asignar cadena de "finCurva procesado correctamente"
                    //msj = MSJ_FIN_CURVA_PROC;
                }
                
                // -> la diferencia entre el torque leido y la consigna aplicada es excesiva
                if( (torque > consigna + 2*TORQUE_ERROR_MAX) || (consigna > torque + 2*TORQUE_ERROR_MAX) )
                {
                    estado = EST_INIC_SIM_TURB;
                    k = 254; // forzar condici�n c_iCurvas superada (i>c_iCurvas), para finalizar simulaci�n
                    // asignar cadena de "error: diferencia excesiva entre torque le�do y consigna"
                    msj = MSJ_TORQ_CONS_DIF;
                    //// PRUEBA ////
                    msj2 = consigna;
                    msj3 = torque;
                    msj4 = omega;
                    //// PRUEBA ////
                }
                
                // -> omega supera un segundo umbral m�ximo (seguro en caso de falla)
                if( omega > omega_max + 2*OMEGA_ERROR_MAX )
                {
                    estado = EST_INIC_SIM_TURB;
                    k = 254; // forzar condici�n c_iCurvas superada (i>c_iCurvas), para finalizar simulaci�n
                    // asignar cadena de "error: segundo umbral m�ximo de omega superado"
                    msj = MSJ_OMEGA_SUP_MAX2;
                    //// PRUEBA ////
                    msj2 = consigna;
                    msj3 = torque;
                    msj4 = omega;
                    //// PRUEBA ////
                }
                
                // -> se activ� el fin de simulaci�n
                if(finSim == 1)
                {
                    estado = EST_INIC_SIM_TURB;
                    k = 254; // forzar condici�n c_iCurvas superada (i>c_iCurvas), para finalizar simulaci�n
                    // asignar cadena de "finSim procesado correctamente"
                    //msj = MSJ_FIN_SIM_PROC;
                }
                
                // escribir valor de consigna correspondiente
                escribirDAC_consigna(consigna);
                
                if(msj!=0)
                {
                    enviarUART(msj); // a esta cadena de caracteres se le asigna los datos a enviar a la PC para identificar la situaci�n en cada caso
                    
                    //// PRUEBA ////
                    //enviarUART(msj2);
                    //enviarUART(msj3);
                    //enviarUART(msj4);
                    //// PRUEBA ////
                    
                    if(msj==MSJ_REG_PERM)
                    {
                        __delay_ms(PERIODO_ACT_CONS_RP_MS-PERIODO_ACT_CONS_MS); // delay extra, incrementa periodo de actualizaci�n de consigna
                    }
                    msj = 0;
                }
                
                break;
				
			case EST_ESPERA_COM:
                
                // indicador de simiulaci�n en curso
                LATCbits.LATC6 = 0;
                
                if(prim_ingr_esp_com)
                {
                    // detener motor
                    motor_detener();
                    k = 255; // reiniciar k para la siguiente simulaci�n
                    prim_ingr_esp_com = 0; // desactivar indicador de primer ingreso a estado ESPERA_COM
                }
                
				break;
				
			default:
                
				Error(0,0); // solo es posible con un error en la programaci�n
		}
		
	}
    return;
}

// funci�n para el manejo de errores
void Error(uint8_t dato0, uint8_t dato1)
{
    uint8_t d = dato0;
    d = dato1;
    motor_detener();
    escribirDAC_consigna(0);
    INTCONbits.GIE = 0; // bajar GIE
    while(1);
}

// funci�n con el vector de interrupciones
void interrupt rsi(void)
{
    
    INTCONbits.GIE = 0; // bajar GIE
    
    // interrupci�n UART
    if(PIR1bits.RCIF)
    {
        uint8_t datoRx = RC1REG;
        uint8_t msj_inc = 1; // indicador de mensaje incoherente
        
        if(estado == EST_SIM_TURB)
        {
            if(datoRx == MSJ_FIN_CURVA)
            {
                finCurva = 1;
                msj_inc = 0;
            }
            if(datoRx == MSJ_FIN_SIM)
            {
                finSim = 1;
                msj_inc = 0;
            }
        }
        if(estado == EST_ESPERA_COM)
        {
            if( (datoRx == EST_CONFIG_SIM) || (datoRx == EST_INIC_SIM_TURB) )
            {
                estado = datoRx;
                msj_inc = 0;
            }
        }
        
        if(msj_inc) // comunicaci�n incoherente
        {
            Error(datoRx,0xE2); // error de respuesta incoherente de la PC
        }
    }
    
    // interrupci�n del TMR2
    if(PIR1bits.TMR2IF) // cuando ocurre esta interrupci�n el uC env�a un "est�s ah�?" a la PC
    {
        // los par�metros del Timer se definen asumiento una frec de clk de 4 MHz
        uint8_t rta, flag;
        
        if( (estado == EST_SIM_TURB) || (estado == EST_INIC_SIM_TURB) )
        {
            // //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA ////
            
            // intercambio "est�s ah�?"/"ac� estoy"
            enviarUART(MSJ_ESTAS_AHI);
            
            /////////////////////////////////////////////////////////////
            /////// forma casera de extender el periodo de consulta /////
            //__delay_ms(200);
            /////// forma casera de extender el periodo de consulta /////
            /////////////////////////////////////////////////////////////
            
            
            flag = recibirUART_timeout(&rta);
            
            if( (rta != MSJ_ACA_ESTOY) || (!flag) )
            {
                Error(rta,0xF2); // error de NO respuesta de la PC o respuesta incoherente
            }
            // //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA //// PRUEBA ////
        }
        else
        {
            // solo posible en caso de error de programaci�n (xq la interrupci�n no deber�a habilitarse en ning�n otro estado)
            Error(0,0);
        }
        PIR1bits.TMR2IF = 0; // bajar flag de interrupci�n
    }
    
    INTCONbits.GIE = 1; // subir GIE
    
}
