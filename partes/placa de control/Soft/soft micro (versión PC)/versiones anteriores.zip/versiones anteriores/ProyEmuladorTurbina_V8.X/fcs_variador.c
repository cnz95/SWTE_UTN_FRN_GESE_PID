// fcs que envian/reciben datos e instrucciones hacia/desde el variador

#include <xc.h>

#include "fcs_variador.h"
//#include <pic16f1619.h>
#define _XTAL_FREQ 4000000

void motor_habilitar(void)
{
    LATBbits.LATB4 = 1; // habilitaci�n = 1
}

void motor_detener(void)
{
    LATBbits.LATB4 = 0; // habilitaci�n = 0
    LATBbits.LATB6 = 0; // sentido de giro derecha = 0
    LATBbits.LATB5 = 0; // sentido de giro izquierda = 0
}

void motor_girar_izq(void)
{
    motor_detener();
    __delay_us(100);
    motor_habilitar();
    __delay_us(100);
    LATBbits.LATB5 = 1; // sentido de giro izquierda = 1
    __delay_ms(100);
    LATBbits.LATB5 = 0; // sentido de giro izquierda = 0
}

void motor_girar_der(void)
{
    motor_detener();
    __delay_us(100);
    motor_habilitar();
    __delay_us(100);
    LATBbits.LATB6 = 1; // sentido de giro derecha = 1
    __delay_ms(100);
    LATBbits.LATB6 = 0; // sentido de giro derecha = 0
}

uint8_t leerADC2_torque(void)
{
    uint8_t ADC;
    ADCON0bits.CHS = 2;     // selecci�n de canal de entrada -> AN2
    __delay_us(5);                  // T_ACQ
    ADCON0bits.GO_nDONE = 1;        // iniciar conversi�n
    //LATAbits.LATA5 = 1;             // led conversi�n iniciada
    while(ADCON0bits.GO_nDONE == 1);// espera a finalizar conversi�n
    //LATAbits.LATA5 = 0;             // led conversi�n terminada
    ADC = ADRESH;                   // valor digital CDA = valor digital CAD
    //__delay_ms(500);
    return ADC;
}

uint8_t leerADC4_omega(void)
{
    uint8_t ADC;
    ADCON0bits.CHS = 4;     // selecci�n de canal de entrada -> AN4
    __delay_us(5);                  // T_ACQ
    ADCON0bits.GO_nDONE = 1;        // iniciar conversi�n
    //LATAbits.LATA5 = 1;             // led conversi�n iniciada
    while(ADCON0bits.GO_nDONE == 1);// espera a finalizar conversi�n
    //LATAbits.LATA5 = 0;             // led conversi�n terminada
    ADC = ADRESH;                   // valor digital CDA = valor digital CAD
    //__delay_ms(500);
    return ADC;
}

void escribirDAC_consigna(uint8_t consigna)
{
    DAC1CON1 = consigna;
    // delay ?????????????????????????????????????????????
}