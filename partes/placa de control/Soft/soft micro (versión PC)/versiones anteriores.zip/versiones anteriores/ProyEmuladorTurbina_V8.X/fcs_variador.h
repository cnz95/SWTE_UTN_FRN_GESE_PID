
#include <stdint.h>


void motor_habilitar(void);

void motor_detener(void);

void motor_girar_izq(void);

void motor_girar_der(void);

uint8_t leerADC2_torque(void);

uint8_t leerADC4_omega(void);

void escribirDAC_consigna(uint8_t consigna);