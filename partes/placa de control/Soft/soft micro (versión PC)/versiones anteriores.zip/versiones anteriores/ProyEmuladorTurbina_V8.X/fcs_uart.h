
#include <stdint.h>

void enviarUART(uint8_t dato);

uint8_t recibirUART(void);

uint8_t recibirUART_timeout(uint8_t* RxBuffer);

uint8_t recibirComando(void);

uint8_t recibirDato(void);

uint8_t recibirTabla(uint8_t **Tabla);