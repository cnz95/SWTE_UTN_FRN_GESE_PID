
#define _XTAL_FREQ 4000000

// constantes de cantidad de filas y columnas de la tabla
//#define	CANT_F	14
//#define	CANT_C	13

//#define TIMEOUT_UART_TMR0 224 // (Tm = 8ms p/TMR0inicial = 255-31 : Tm(real) = 7,936 ms)
//#define TIMEOUT_UART_TMR0 193 // 255-62
#define TIMEOUT_UART_TMR0 0

#include <xc.h>
#include "fcs_uart.h"

void enviarUART(uint8_t dato)
{
    
    __delay_us(100);
    
    // comprobar que el bufer se encuentra desocupado
    while(PIR1bits.TXIF == 0);
    TX1REG = dato;
}

uint8_t recibirUART(void)
{
    uint8_t dato;
    if(RC1STAbits.OERR == 1)    // Overrun Error
    {
        RC1STAbits.SPEN = 0;    // reiniciar m�dulo UART
        __delay_us(100);                                                                    //// ES NECESARIO ???
        RC1STAbits.SPEN = 1;
    }
    while(PIR1bits.RCIF == 0);  // esperar a que haya un dato listo para leer
    dato = RC1REG;
    TMR2 = 0; // reiniciar TMR2 (tiempo inactividad PC)
    return dato;
    // hay un problema si recibe + de tres transmisioes consecutivas antes de leer el reg
}

// recibir byte por UART, con timeout
// el valor de retorno indica si se recibi� alg�n dato
uint8_t recibirUART_timeout(uint8_t* RxBuffer)
{
    
    *RxBuffer = 0;
    
    if(RC1STAbits.OERR == 1)    // Overrun Error
    {
        RC1STAbits.SPEN = 0;    // reiniciar m�dulo UART
        __delay_us(100);                                                                    //// ES NECESARIO ???
        RC1STAbits.SPEN = 1;
    }
    
    TMR0 = TIMEOUT_UART_TMR0;
    OPTION_REGbits.TMR0CS = 0; // TMR0 ON
    while( (PIR1bits.RCIF == 0) && (INTCONbits.TMR0IF == 0) );  // esperar a que haya un dato listo para leer o desborde el timer
    OPTION_REGbits.TMR0CS = 1; // TMR0 OFF
    
    INTCONbits.TMR0IF = 0;
    // puede ir despu�s del if, pero podr�a ocurrir el desborde del TMR despu�s de la recepci�n del byte y antes de detener el TMR
    
    if(PIR1bits.RCIF == 1)
    {
        *RxBuffer = RC1REG;
        TMR2 = 0; // reiniciar TMR2 (tiempo inactividad PC)
        return 1; // se recibi� un dato
    }
    
    //INTCONbits.TMR0IF = 0;
    
    return 0; // no se recibi� nada
    
    // hay un problema si recibe + de tres transmisioes consecutivas antes de leer el reg
}

uint8_t recibirComando(void)
{
    // retorna 0 si:    no se recibe ning�n comando v�lido
    // retorna 255 si:  falla el bit de paridad
    // retorna el valor recibido: si es un comando v�lido y concuerda el bit de paridad
    
    
}

uint8_t recibirDato(void)
{
    // retorna 255 si:    falla el bit de paridad
    // retorna el valor recibido: si concuerda el bit de paridad
}

uint8_t recibirTabla(uint8_t **Tabla)
{
    //
}
