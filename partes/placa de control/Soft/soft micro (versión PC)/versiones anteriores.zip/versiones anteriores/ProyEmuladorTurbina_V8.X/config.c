
#include "config.h"
#include <xc.h>

void configUC(void)
{
    OSCCONbits.IRCF = 13;   // frecuencia de oscilador 4MHz (IRCF=1101=13)

    ANSELC = 0;
    TRISA = 0;
    ANSELA = 0;
    
    TRISAbits.TRISA2 = 1;
    TRISCbits.TRISC0 = 1;
    ANSELAbits.ANSA2 = 1;
    ANSELCbits.ANSC0 = 1;
    
    TRISCbits.TRISC5 = 0;
    TRISCbits.TRISC4 = 1;
    
    TRISBbits.TRISB4 = 0;
    TRISBbits.TRISB5 = 0;
    TRISBbits.TRISB6 = 0;
    
    ANSELBbits.ANSB4 = 0;
    ANSELBbits.ANSB5 = 0;
    ANSELBbits.ANSB6 = 0;
    
    LATA = 0;
    LATB = 0;
    LATC = 0;
}

void configADC(void)
{
    // configuraci�n ADC
    ADCON1bits.ADFM = 0;    // alineaci�n de bits -> izquierda (se desprecian los 2 bits menos significativos) !!! VER
    ADCON1bits.ADCS = 0;    // fuente de reloj -> Fosc/2 (el m�s r�pido ???)
    ADCON1bits.ADPREF = 0;  // voltaje de referencia positivo -> Vdd (+5v)
    //ADCON0bits.CHS = 2;     // selecci�n de canal de entrada -> AN2
    //ADCON0bits.CHS = 4;     // selecci�n de canal de entrada -> AN4
    ADCON0bits.ADON = 1;    // habilitar m�dulo conversor
}

void configDAC(void)
{
    // configuraci�n CAD
    DAC1CON0bits.DAC1OE = 1;    // salida de CDA conectada a DAC1OUT1 (enable)
    DAC1CON0bits.DAC1PSS = 0;   // voltaje de referencia -> Vdd
    DAC1CON0bits.DAC1EN = 1;    // habilitar conversor
    // la salida se conecta por defecto a AN0 (no remapeable)
}

void configUART(void)
{
    SP1BRGH = 0;
    SP1BRGL = 0x19;
    RC5PPS = 0x12;  // remapear TX a pin RC5 --------------------------------------------------------- !!! HAY QUE CAMBIARLO
    RXPPS = 0x14;   // remapear RX a pin RC4
    BAUD1CONbits.BRG16 = 1; // para esto hay que sacar cuentas
    TX1STAbits.SYNC = 0;    // modo as�ncrono
    TX1STAbits.BRGH = 0;    // selecci�n de tasa debaudios alta -> baja velocidad (desactivada)
    TX1STAbits.TXEN = 1;    // habilitar circuito de transmisi�n (configura el pin)
    RC1STAbits.CREN = 1;    // habilita la circuiteria de recepci�n
    RC1STAbits.SPEN = 1;    // habilitar el m�dulo USART (tambi�n establece los pines CK y TX como salidas digitales)
    
    // configuraci�n interrupci�n // se habilita inmediatamente porque se inicia en el estado "esperando comunicaci�n"
    PIE1bits.RCIE = 1; // habilitaci�n de interrupci�n por recepci�n de dato por UART
    INTCONbits.PEIE = 1; // habilitaci�n de interrupciones de perif�ricos
    INTCONbits.GIE = 1; // habilitaci�n de interrupciones de perif�ricos
}

void configTMR0(void) // Timer para el Timeout de la recepci�n por UART
{
    // configuraci�n Timer0 
    // los par�metros del Timer se definen asumiento una frec de clk de 4 MHz (Tm = 8ms p/TMR0inicial = 255-31 : Tm(real) = 7,936 ms)
    OPTION_REGbits.PSA = 0;
    OPTION_REGbits.PS = 7;
    // no se utiliza la interrupci�n de este Timer
    
    // p/ una Fosc = 16 MHz
    // desborda por cada periodo de muestreo Tm
    // esta configuraci�n permite Tm desde 64 us hasta 16,32 ms . (por los posiles valores iniciales de TMR0)
    // p/ Tm = 2 ms (Fm = 500 Sa/s) :  TMR0inicial = 255 - 31 :  Tm(real) = 1,984 ms
    // p/ Tm = 10,42 ms (Fm = 96 Sa/s) :  TMR0inicial = 255 - 162 :  Tm(real) = 10,368 ms
    // p/ Tm = 12,5 ms (Fm = 80 Sa/s) :  TMR0inicial = 255 - 195 :  Tm(real) = 12,48 ms
}

void configTMR2(void)
{
    // configuraci�n Timer2
    
    // // desborda cada 125 ms (Fosc = 16MHz) e incrementa la variable global c (interrupci�n)
    // // si se utiliza un delta-TMR0 de 244 ( TMR2 inicial = 255 - 244 = 11 )
    // => p/Fosc = 4MHz y delta-TMR0 de 244 ocurre la interrupci�n c/ 500 ms  ->  Tm(real) = 499,712 ms
    PR2 = 244;
    
    // los par�metros del Timer se definen asumiento una frec de clk de 4 MHz
    T2HLTbits.MODE = 0; // Timer simple
    //T2CONbits.CKPS = 7; // clock prescaler = 1:128
    T2CONbits.CKPS = 7;
    //T2CONbits.OUTPS = 15; // output postscaler = 1:16
    T2CONbits.OUTPS = 15;
    T2CLKCONbits.CS = 0; // Fosc/4
    
    //T2HLTbits.PSYNC = 1;//no cambi� nada
    
    // configuraci�n interrupciones
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE1bits.TMR2IE = 1;
}

void configCRC8(void)
{
    // manual calculation
    
    // XOR polynomial 0x00 -> CRCXORH y CRCXORL // por defecto empiezan en cero
    CRCXORH = 0x01;
    CRCXORL = 0xD5;
    
    // length of the data word = 8  ->  DLEN = 7 (CRCCON1)
    CRCCON1bits.DLEN = 7;
    // length of the polynomial = 9 -> PLEN = 7 (CRCCON1)
    CRCCON1bits.PLEN = 7;
    
    // no shifting in trailing zeros -> ACCM (CRCCON0)
    CRCCON0bits.ACCM = 1;
    // MSb should be shifted first -> SHIFTM (CRCCON0)
    CRCCON0bits.SHIFTM = 0;
    
    // enable module
    CRCCON0bits.EN = 1;
    
    
    // para probar configuraci�n, BORRAR
    LATAbits.LATA5 = 1;
    // para probar configuraci�n, BORRAR
}