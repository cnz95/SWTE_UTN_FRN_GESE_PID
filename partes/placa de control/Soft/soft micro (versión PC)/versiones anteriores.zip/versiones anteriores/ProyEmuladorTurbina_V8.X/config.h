

void configUC(void);

void configADC(void);

void configDAC(void);

void configUART(void);

void configTMR0(void);

void configTMR2(void);

void configCRC8(void);