
#include <stdint.h>


uint8_t busq_min(uint8_t *v, uint8_t cant);

uint8_t busq_max(uint8_t *v, uint8_t cant);

uint8_t interp(uint8_t x, uint8_t x1, uint8_t x2, uint8_t y1, uint8_t y2);

uint8_t calcCRC8(uint8_t *v, uint8_t n);