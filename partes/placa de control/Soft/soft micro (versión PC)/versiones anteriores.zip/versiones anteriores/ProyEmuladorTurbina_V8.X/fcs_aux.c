


#include <pic16f1619.h>

#include "fcs_variador.h"

uint8_t busq_min(uint8_t *v, uint8_t cant)
{
    uint8_t i, imin;
    // algoritmo simple dado que la extensi�n de los vectores no es importante (por lo tanto la velocidad de procesamiento tampoco)
    for(i=1, imin = 0;i<cant;i++)
    {
        if( v[i] < v[imin] )
        {
            imin = i;
        }
    }
    return v[imin];
}

uint8_t busq_max(uint8_t *v, uint8_t cant)
{
    uint8_t i, imax;
    // algoritmo simple dado que la extensi�n de los vectores no es importante (por lo tanto la velocidad de procesamiento tampoco)
    for(i=1, imax = 0;i<cant;i++)
    {
        if( v[i] > v[imax] )
        {
            imax = i;
        }
    }
    return v[imax];
}


uint8_t interp(uint8_t x, uint8_t x1, uint8_t x2, uint8_t y1, uint8_t y2)
{
    return (uint8_t) ((x-x1) * (y2-y1)/(x2-x1) + y1); // interpolaci�n lineal
    // cuando el resultado tiene decimales la conversi�n los trunca
}

uint8_t calcCRC8(uint8_t *v, uint8_t n)
{
    uint8_t i;
    
    CRCACCL = 0;
    CRCACCH = 0;
    
    // begin the shifting process -> CRCGO (CRCCON0)
    CRCCON0bits.CRCGO = 1;
    
    for( i=0 ; i<n ; i++ )
    {
        // monitor FULL bit (CRCCON0), FULL is zero: a new data can be written
        while(CRCCON0bits.FULL);
        // write CRCDATL register with data // el CRCDATH no se utiliza porque los datos son de 8 bits
        CRCDATL = v[i];
    }
    
    // after the last data, monitor CRCIF, when is high, CRCACC will hold the check value
    while(PIR4bits.CRCIF == 0);
    PIR4bits.CRCIF = 0;
    
    CRCCON0bits.CRCGO = 0; // es necesario ???
    
    return CRCACCL;
}